# Assignment 4: Building a React App

Overall I found the react app to be a little easier to build than the plain HTML version created for the last assignment. I think this is largely because I had the HTML code to reference as I decided to build mine to be as similar as possible to my pure HTML/js version. This made it so I didn't have to spend as much time playing with CSS and working through the process flow of the program. Beyond the use of a reference, I don't really have a preference between the two methods however I do like how components work in React. I think it makes the code easier to read and understand.

I also have some previous experience with both react and plain HTML, so this assignment was fun to work on my skills and see how things are done differently in both the language. This is the first time I've emulated the same site in both react and HTML, so it was interesting to see how the two compare.

The biggest challenge I faced with the react version of this assignment was getting the update button on the card to communicate with the parent component correctly. I also struggled with getting the toggle stats to update the cards html correctly. I kept getting errors for various reasons, though I was able to get the bugs fixed and it works correctly now. I also had some issues with the CSS, but I was able to get that fixed as well.
